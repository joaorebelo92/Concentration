<?php

use Illuminate\Database\Seeder;

class gamesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        /*
        GameTable::Create([
        	'nline' => 2, 
        	'ncolumn' => 2, 
        	'game_maker' => 3, 
        	'game_invited' => NULL, 
        	'state' => 'WAITING', 
        	'typeOfGame' => 'PUBLIC'
        ]);
        
        GameTable::Create([
        	'nline' => 4, 
        	'ncolumn' => 4, 
        	'game_maker' => 3, 
        	'game_invited' => NULL, 
        	'state' => 'WAITING', 
        	'typeOfGame' => 'PRIVATE'
        ]);

        GameTable::Create([
        	'nline' => 2, 
        	'ncolumn' => 2, 
        	'game_maker' => 4, 
        	'game_invited' => NULL, 
        	'state' => 'WAITING', 
        	'typeOfGame' => 'PUBLIC'
        ]);*/
        // id
        // nline
        // ncolumn
        // game_maker
        // game_invited
        // state
        // typeOfGame
    }
}
